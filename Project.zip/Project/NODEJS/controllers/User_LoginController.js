 
const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { User_Login } = require('../models/User_Login');

// => localhost:3000/employees/
router.get('/', (req, res) => {
    console.log ('11 '+req.params.id);
    User_Login.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.get('/:user_id', (req, res) => {
    console.log (' '+req.params.user_id);
    
    if (!ObjectId.isValid(req.params.user_id))
    console.log (' invalid record');
        return res.status(400).send(`No record with given id : ${req.params.user_id}`);

    User_Login.findById(req.params.id, (err, doc) => {
        if (!err) { res.send(doc);
            console.log (' inside doc'); }
        
        else { console.log('Error in Retriving User_Login :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.post('/', (req, res) => {
    var emp = new User_Login({
        user_id: req.body.user_id,
        password: req.body.password,
        account_number: req.body.account_number,
        address: req.body.address,
        user_name: req.body.user_name,
        DOB: req.body.DOB,
    });
    emp.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in User_Login Save :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var emp = {
        user_id: req.body.user_id,
        password: req.body.password,
        account_number: req.body.account_number,
        address: req.body.address,
        user_name: req.body.user_name,
        DOB: req.body.DOB,
    };
    User_Login.findByIdAndUpdate(req.params.id, { $set: emp }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in User_Login Update :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    User_Login.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in User_Login Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports = router;

