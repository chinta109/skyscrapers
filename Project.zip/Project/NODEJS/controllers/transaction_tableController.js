 
const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { transaction_table } = require('../models/transaction_table');

// => localhost:3000/employees/
router.get('/', (req, res) => {
    transaction_table.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.get('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    transaction_table.findById(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Retriving transaction_table :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.post('/', (req, res) => {
    var emp = new transaction_table({
        user_name: req.body.user_name,
        user_id: req.body.user_id,
        transaction_type: req.body.transaction_type,
        Amount: req.body.Amount
    });
    emp.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in transaction_table Save :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var emp = {
        user_name: req.body.user_name,
        user_id: req.body.user_id,
        transaction_type: req.body.transaction_type,
        Amount: req.body.Amount
    };
    transaction_table.findByIdAndUpdate(req.params.id, { $set: emp }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in transaction_table Update :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    transaction_table.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in transaction_table Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports = router;

