const mongoose = require('mongoose');

var transaction_table = mongoose.model('transaction_table', {
    transaction_id: { type: Number },
    user_id: {type: Number},
    transaction_type: { type: String },
    Amount: { type: Number },
    user_name: { type: String }

});

module.exports = { transaction_table };