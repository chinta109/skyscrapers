const mongoose = require('mongoose');

var User_Login = mongoose.model('User_Login', {
    user_id: { type: Number },
    password: { type: String },
    account_number: { type: String },
    address: { type: String },
    user_name: { type: String },
    DOB: { type: String }

});

module.exports = { User_Login };
