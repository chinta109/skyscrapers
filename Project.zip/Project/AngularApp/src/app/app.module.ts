import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injectable } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { RouterModule, Routes, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserLoginComponent } from './User_Login/User_Login.component';
import { TransactionDetailsComponent } from './transaction_table/transaction-details/transaction-details.component';

@Injectable()
class CanActivateTeam implements CanActivate {
  constructor(
    private router: Router
  ) { }
  currentUserLogin: boolean;
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    this.currentUserLogin = localStorage.getItem('isUserLogin') == 'true';
    if (this.currentUserLogin) {
      return true;
    }
    else{
      this.router.navigate(['/login']);
    }
  }
}

const appRoutes: Routes = [
  { path: 'transactions', component: TransactionDetailsComponent, canActivate: [CanActivateTeam] },
  { path:'login', component: UserLoginComponent}

]

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    UserLoginComponent,
    TransactionDetailsComponent
  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
    BrowserModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [CanActivateTeam],
  bootstrap: [AppComponent]
})
export class AppModule { }
