import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { Router } from '@angular/router';
import { User_LoginService } from '../shared/User_Login.service';
import { User_Login } from '../shared/User_Login.model';

declare var M: any;

@Component({
  selector: 'user-login',
  templateUrl: './User_Login.component.html',
  styleUrls: ['./User_Login.component.css'],
 
  providers: [User_LoginService]
})
export class UserLoginComponent implements OnInit {

  constructor(
    private router: Router,
    public user_loginService: User_LoginService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.user_loginService.selectedUser_Login = {
      user_id: null,
      password: "", 
      account_number: "",
      user_name: "",
      DOB: "",
    }
  }

  
  onSubmit(form: NgForm) {
      this.user_loginService.getUser_Login(this.user_loginService.selectedUser_Login.user_id).subscribe((res) => {
        if(this.user_loginService.selectedUser_Login.password == (res as User_Login).password){
          localStorage.setItem("isUserLogin", 'true');          
          this.router.navigate(['./transactions']);
        }
        else{
          localStorage.setItem("isUserLogin", 'false'); 
        }
      });
  }

}