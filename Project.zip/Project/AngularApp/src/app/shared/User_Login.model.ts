export class User_Login {
    user_id:  Number;
    password: String ;
    account_number: String ;
    user_name: String ;
    DOB:  String ;
}