import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import { User_Login } from './User_Login.model';

@Injectable()
export class User_LoginService {
  selectedUser_Login: User_Login;
  user_Login: User_Login[];
  readonly baseURL = 'http://localhost:3000/User_Login';

  constructor(private http: HttpClient) { }

  postUser_Login(emp: User_Login) {
    return this.http.post(this.baseURL, emp);
  }

  getUser_LoginList() {
    return this.http.get(this.baseURL);
  }

  getUser_Login(user_id:any){
    return this.http.get(this.baseURL + `/${user_id}`);
  }

  putUser_Login(emp: User_Login) {
    return this.http.put(this.baseURL + `/${emp.user_id}`, emp);
  }

  deleteUser_Login(_id: string) {
    return this.http.delete(this.baseURL + `/${_id}`);
  }

}